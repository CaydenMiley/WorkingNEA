﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SimulatorWithoutMovement
{
    internal class Resistor
    {
        private Rectangle resistorRectangle;

        public Resistor(Canvas canvas, double startX, double startY)
        {
            resistorRectangle = new Rectangle
            {
                Width = 40,
                Height = 20,
                Fill = Brushes.Brown
            };

            Canvas.SetLeft(resistorRectangle, startX);
            Canvas.SetTop(resistorRectangle, startY);
            canvas.Children.Add(resistorRectangle);

        }
    }
}
