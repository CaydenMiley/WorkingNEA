﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SimulatorWithoutMovement        
{
    public partial class MainWindow : Window
    {
        private bool isDragging;
        private UIElement currentShape;
        private Point offset;
        private int interval = 100; // Interval for which the snap points are added
        private double maxX = 1100; // Maximum X-coordinate that the icons can snap to
        private double maxY = 200; // Maximum Y-coordinate that the icons can snap to
        private List<Point> occupiedSnapPoints = new List<Point>();
        private Point? currentShapeSnapPoint = null;
        private List<Point> snapPoints = new List<Point>(); // List of points for the shapes to snap to
        private Resistor currentResistor;

        public MainWindow()
        {
            
            InitializeComponent();
            Button SpawnResistor = new Button
            {
                Content = new TextBlock
                {
                    Text = "Resistor",
                    Foreground = Brushes.Black
                },
                Width = 80,
                Height = 30,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(10)
            };
            




            
            // Calls the method to place shapes at specific coordinates
            PlaceShapes();

            // Calls the method to add snap points to the canvas at regular intervals
            InitializeSnapPoints();
            SpawnResistor.Click += IconButton_Click;
            Canvas.Children.Add(SpawnResistor);
            Resistor myResistor = new Resistor(Canvas, 200,200);
            Wire myWire = new Wire(Canvas);
            Lamp myLamp = new Lamp(Canvas, 300, 300);
        }
        private void IconButton_Click(object sender, RoutedEventArgs e)
        {
            bool buttonClicked = true;

            // Perform additional actions if needed
            if (buttonClicked)
            {
                DrawResistor(100, 0);
            }
        }
        private void PlaceShapes()
        {
            // Method to place shapes where needed
            DrawResistor(0, 100);
            DrawResistor(0, 200);
            DrawLamp(0, 300, 100, 100);
            

        }

        //Method to create resistor
        private void DrawResistor(double x, double y)
        {
            Rectangle Resistor = new Rectangle
            {
                Width = 105,
                Height = 100,
                Fill = Brushes.Green,
            };

            Canvas.SetLeft(Resistor, x);
            Canvas.SetTop(Resistor, y);

            Resistor.MouseLeftButtonDown += Shape_MouseLeftButtonDown;
            Resistor.MouseLeftButtonUp += Shape_MouseLeftButtonUp;
            Resistor.MouseMove += Shape_MouseMove;


            Canvas.Children.Add(Resistor);

        }
        private void DrawLamp(double x, double y, double width, double height)
        {
            Ellipse Lamp = new Ellipse
            {
                Width = width,
                Height = height,
                Fill = Brushes.Green,
            };

            Canvas.SetLeft(Lamp, x);
            Canvas.SetTop(Lamp, y);

            Lamp.MouseLeftButtonDown += Shape_MouseLeftButtonDown;
            Lamp.MouseLeftButtonUp += Shape_MouseLeftButtonUp;
            Lamp.MouseMove += Shape_MouseMove;


            Canvas.Children.Add(Lamp);

        }
        public void Shape_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            currentShape = (UIElement)sender;
            offset = e.GetPosition(currentShape);
            currentShape.CaptureMouse();
        }

        public void Shape_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (isDragging)
            {
                isDragging = false;
                currentShape.ReleaseMouseCapture();
            }
        }

        public void Shape_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point mousePosition = e.GetPosition(Canvas);
                double newX = mousePosition.X - offset.X;
                double newY = mousePosition.Y - offset.Y;

                // Snap to the nearest snap point
                Point snappedPosition = GetNearestSnapPoint(newX, newY);
                Canvas.SetLeft(currentShape, snappedPosition.X);
                Canvas.SetTop(currentShape, snappedPosition.Y);
            }
        }

        public void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                // This prevents clicking on shapes when dragging
                e.Handled = true;
            }
        }

        public void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!isDragging)
            {
                // Release focus from any currently dragged shape
                if (currentShape != null)
                {
                    currentShape.ReleaseMouseCapture();
                    currentShape = null;
                }
            }
        }

        //Method to find the nearest snap point for each shape when selected
        public Point GetNearestSnapPoint(double x, double y)
        {
            Point currentPosition = new Point(x, y);
            Point nearestSnapPoint = snapPoints.OrderBy(p => CalculateDistance(currentPosition, p)).First();
            return nearestSnapPoint;
        }
        public double CalculateDistance(Point p1, Point p2)
        {
            double deltaX = p2.X - p1.X;
            double deltaY = p2.Y - p1.Y;
            return Math.Sqrt(deltaX * deltaX + deltaY * deltaY);
        }
        public void InitializeSnapPoints()
        {
            int screenWidth = (int)SystemParameters.PrimaryScreenWidth;
            int screenHeight = (int)SystemParameters.PrimaryScreenHeight;

            // Add snap points at regular intervals along the X-axis until reaching screenWidth
            for (double currentX = 0; currentX <= screenWidth; currentX += interval)
            {
                // Add snap points at regular intervals along the Y-axis until reaching screenHeight
                for (double currentY = 0; currentY <= screenHeight; currentY += interval)
                {
                    snapPoints.Add(new Point(currentX, currentY));


                }
            }
            foreach (Point snapPoint in snapPoints)
            {
                Ellipse ellipse = new Ellipse
                {
                    Width = 5,
                    Height = 5,
                    Fill = Brushes.Black,
                    Stroke = Brushes.Black,
                    StrokeThickness = 0.1,
                    IsEnabled = false
                };

                Canvas.SetLeft(ellipse, snapPoint.X);
                Canvas.SetTop(ellipse, snapPoint.Y);

                // Add the Ellipse to the grid container or canvas
                Canvas.Children.Add(ellipse);
            }
        }
    }
}