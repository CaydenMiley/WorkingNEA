﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SimulatorWithoutMovement
{
    internal class Lamp
    {
        private Ellipse LampEllipse;

        public Lamp(Canvas canvas, double startX, double startY)
        {
            LampEllipse = new Ellipse
            {
                Width = 100,
                Height = 100,
                Fill = Brushes.Purple
            };

            Canvas.SetLeft(LampEllipse, startX);
            Canvas.SetTop(LampEllipse, startY);
            
            canvas.Children.Add(LampEllipse);

        }
    }
}
